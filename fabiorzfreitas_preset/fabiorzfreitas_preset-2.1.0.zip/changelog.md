**<span style="color:#56adda">2.1.0</span>**
- Video_codec.

**<span style="color:#56adda">2.0.1</span>**
- Minor FFmpeg.

**<span style="color:#56adda">2.0.0</span>**
- FFmpeg fix.

**<span style="color:#56adda">1.7.2</span>**
- Removed quotes.

**<span style="color:#56adda">1.7.1</span>**
- Commas.

**<span style="color:#56adda">1.7.0</span>**
- Popen list.

**<span style="color:#56adda">1.6.2</span>**
- Revert last change.

**<span style="color:#56adda">1.6.1</span>**
- data['exec_command'] now is list.

**<span style="color:#56adda">1.6.0</span>**
- FFmpeg -y.

**<span style="color:#56adda">1.5.0</span>**
- Minor errors.

**<span style="color:#56adda">1.4.0</span>**
- FFProbe_data['streams'] fix.

**<span style="color:#56adda">1.3.2</span>**
- Another quote fix.

**<span style="color:#56adda">1.3.1</span>**
- Now that file_out is fixed, improved quotes.

**<span style="color:#56adda">1.3.0</span>**
- Perhaps cache file is the issue.

**<span style="color:#56adda">1.2.3</span>**
- Different quote fix.

**<span style="color:#56adda">1.2.2</span>**
- Trying to fix loop.

**<span style="color:#56adda">1.2.1</span>**
- Last fix was not good.

**<span style="color:#56adda">1.2.0</span>**
- Fixed quotes around filenames.

**<span style="color:#56adda">1.1.1</span>**
- Small fix on logger output.

**<span style="color:#56adda">1.1.0</span>**
- New logger output, comments on code. Could use type annotation and perhaps another post-processing runner.

**<span style="color:#56adda">1.0.0</span>**
- Everything seems to be working. Further development will simply polish the code.

**<span style="color:#56adda">0.5.0</span>**
- Implemented MKV remuxing.
- 
**<span style="color:#56adda">0.4.0</span>**
- Almost final, needs to implement cache settings and MKV remuxing to otherwise good files. This commit also predates the pull request to lib.ffmpeg.probe.py to add support for chapters.

**<span style="color:#56adda">0.3.0</span>**
- Almost fully functional, it still needs to parse chapters, attachments and metadata. The rest works.

**<span style="color:#56adda">0.2.0</span>**
- Basic functionality seems ok.

**<span style="color:#56adda">0.1.0</span>**
- Not working yet.