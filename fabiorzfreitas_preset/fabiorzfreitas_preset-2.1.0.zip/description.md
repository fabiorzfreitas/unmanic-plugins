This plugin will:

1) Check if the video stream is x264. If not, the output file will change to "Plex Versions\Optimized for TV\FILE";
2) Check if the first audio stream is AC3. If not, it will APPEND an AC3 stream as the first stream;
3) Remove subtitles;
4) Remove chapters, attachments and title metadata;
5) Remux every file to MKV.